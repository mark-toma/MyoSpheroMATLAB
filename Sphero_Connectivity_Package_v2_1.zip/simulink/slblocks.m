function blkStruct = slblocks
blkStruct.Name = 'Sphero Library';
blkStruct.OpenFcn = 'sphero_lib';
blkStruct.MaskInitialization = '';

    %   Copyright 2014 The MathWorks, Inc.